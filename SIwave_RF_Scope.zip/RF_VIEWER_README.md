# SIwave R(f) Scope

A standalone instrument-style Python application that opens two-port S2P data, computes model series resistance R(f), and displays it with two stacked oscilloscope plots and a row inspector. Its layout follows the supplied reference: grey controls, black plots, yellow-green grids and thin pale traces. Excel is not required. CSV export is optional.

## Run on Windows

1. Extract the ZIP into a folder.
2. Install desktop Python 3.10 or later with Tcl/Tk support if it is not already installed. The normal python.org Windows installer supplies Tkinter.
3. Double-click `Launch_RF_Viewer.bat`, or run:

   ```text
   python siwave_rf_viewer.py
   ```

4. Click **Open S2P** to select your export. Click **Demo** to try a clearly labeled synthetic uniform-line example.

No pip packages are required. This application uses Python's standard library and Tkinter. It is a standalone Python 3 GUI, not a script to run inside SIwave's IronPython environment. The program can also start with an input path:

```text
python siwave_rf_viewer.py "C:\results\board.s2p"
python siwave_rf_viewer.py --demo
```

## Inspect every frequency row

- Click either pale trace to choose the nearest frequency row.
- Click a row in the table. Use its scrollbar to browse every point.
- Use Previous / Next or the left and right arrow keys to move one row at a time.
- Enter a one-based row number and click Go.
- Enter frequency in Hz (including scientific notation, e.g. `1e6`) and click Nearest.
- Wheel over the plot to zoom frequency; right-drag to pan. Reset view restores full range.
- Switch the display between ohms and milliohms. The source table always lists ohms explicitly.
- The upper plot shows resistance. Select Impedance phase or Reactance X for the lower plot; its vertical scale is independent and explicitly labeled.
- Enable Log R to examine positive values over a wide range. Zero/negative values remain in the table and inspector; the plot states when log scale hides them.
- Scroll the right inspector for original S11/S12/S21/S22, magnitude/phase, ABCD, phase branch, reconstructed-S residual, per-metre resistance and row checks.
- Copy selected row places the inspector text on the clipboard.

DC is a separate labeled left-hand point when frequency is logarithmic. The plot does not connect DC to the first positive-frequency sample, so it does not pretend that DC is a positive logarithmic frequency.

## Select the physical model

### Uniform line / RLGC

For an identified uniform reciprocal conductor-and-return path, one dominant ordinary passive transmission-line mode, equal real port references and de-embedded reference planes:

```text
theta = gamma * length = acosh((A + D)/2)   [branch tracked]
z_total = theta * B / sinh(theta)
R_total = real(z_total)
R_per_metre = R_total / length
```

The displayed **MODEL SERIES R** is the conductor-and-return series resistance represented by that mode. It is not automatically the resistance of one individual conductor on an arbitrary PCB. Geometry and the Q3D trace/matrix reduction must match before comparison.

Length is in millimetres. It is needed for the per-metre readout; total R uses `theta * B / sinh(theta)` and does not require dividing by length.

**Seed delay (ns)** gives an estimated one-way propagation delay for the initial phase branch. Set it when the sweep starts at an electrically long frequency. With zero seed, the program starts near the lowest forward-phase branch. Low starting frequency and sufficiently dense phase sampling are then essential. It tracks subsequent candidates using frequency continuity and the previous phase slope. Branch tracking cannot guarantee uniqueness from an unknown, sparse S2P; a known delay, additional length or constrained fit may still be needed.

The calculation uses the small-argument Taylor series for `theta / sinh(theta)`. A true DC point with negligible shunt leakage uses `Re(B)`. It detects vanishing transmission, degenerate representations and propagation singularities rather than returning a fabricated resistance.

### Lumped pi / series arm

```text
z_series = B = -1/Y12   [reciprocal pi interpretation]
R_series = real(B)
```

Useful for a physically justified short lumped path with input/output shunts. A reciprocal network can have a terminal pi equivalent even when its series arm is not a physical copper conductor. For a long uniform line, B is not its integrated series impedance; use RLGC instead.

### Series-only fixture

```text
z_series = 2 * Z0 * (1 - S21) / S21
R_series = real(z_series)
```

Use only when the DUT is a series impedance without shunt paths. The program reconstructs the complete ideal-series S matrix and flags mismatch. It does not apply an S21-only fixture formula silently to all layouts.

## Supported input

- Exactly two ports; full single-ended S matrix.
- RI, MA or DB formats; phase is converted from degrees.
- Hz, kHz, MHz or GHz; displayed source frequencies are Hz.
- Equal positive real port reference impedances, read from the file, not hard-coded to 50 ohms.
- Legacy two-port ordering S11, S21, S12, S22.
- A documented Touchstone 2.0 subset: Version, Number of Ports, Number of Frequencies, Two-Port Data Order (`21_12` or `12_21`), same-line two-value Reference, Full Matrix Format, Network Data and End. Zero Number of Noise Frequencies is accepted.
- Blank lines, inline comments and wrapped full records.

Noise blocks, mixed-mode, triangular matrices, non-S data, unequal/complex references and unsupported keywords are rejected with an explanatory error. Multiline `[Reference]` data are intentionally unsupported. Frequencies must be nonnegative, finite and strictly increasing; the program does not silently reorder records.

## What the checks mean

The row flags cover nonpassive S data, nonreciprocity, negative resistance, small transmission, uniform-line mismatch, negative shunt conductance, sparse phase sampling and invalid conversions. Reconstruction compares complex S, not only magnitude.

**Numeric checks pass is not a certification of physical conductor ACR.** Reciprocity/symmetry/reconstruction cannot prove uniform geometry or uniquely partition copper, dielectric and component losses. Negative resistance is preserved rather than clipped. Defaults/tolerances are diagnostic thresholds; export precision and solver convergence must also be assessed for small resistances.

The standalone viewer does not solve Maxwell/SIwave fields, perform automatic fixture de-embedding, or replace a physically matched Q3D comparison. No actual user board has been validated because its S2P and terminal definitions have not been supplied.

## Validation performed

Run the independent checks with:

```text
python -m unittest test_rf_viewer -v
```

Ten tests cover analytic RLGC resistance in RI/MA/DB (including DC), a long line crossing more than seven full phase cycles, a high-frequency starting point with delay seed, nonsymmetric port ordering, 25/50/75-ohm series extraction, a known pi circuit, model mismatch, singular-row recovery, negative-resistance preservation and unsupported file rejection. Tests use independent known circuit quantities, not just a conversion round trip.

The GUI was executed on Windows and checked for demo loading, row/frequency navigation, unit changes, log scale, resizing and editing settings. The included preview shows the actual application with synthetic data. This is not a reproduction of a measured board.

## Papers

- Fang et al. (2018), *Parameter extraction method for the twisted pair cable with rectangular connectors*: https://doi.org/10.1371/journal.pone.0205072
- Degerstrom, Gilbert and Daniel (2008), *Accurate resistance, inductance, capacitance, and conductance (RLCG) from uniform transmission line measurements*: https://doi.org/10.1109/EPEP.2008.4675881
- Eisenstadt and Eo (1992), *S-parameter-based IC interconnect transmission line characterization*: https://doi.org/10.1109/33.159877

## Visual reference

The supplied screenshot was inspected before the final GUI revision. The final application uses its conventional grey instrument controls, sunken white numeric readouts, two vertically stacked black plotting areas, yellow-green graticules, thin pale traces and compact controls on the right. Controls are named for the actual S2P/R(f) task rather than unrelated measurement channels.

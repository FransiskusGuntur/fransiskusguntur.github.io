#!/usr/bin/env python3
"""SIwave R(f) Scope. Python 3.10+, Tkinter, standard library only.
Standalone desktop application, not an embedded IronPython script.
Run: python siwave_rf_viewer.py [file.s2p] [--demo]
"""
import argparse
import cmath
import csv
import io
import math
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

BG = '#e7e7e7'
PANEL = '#efefef'
GRID = '#85872b'
TEXT = '#141414'
MUTED = '#454545'
CYAN = '#007c9f'
AMBER = '#946500'
RED = '#a4142a'
MODES = ('Uniform line / RLGC', 'Lumped pi / series arm', 'Series-only fixture')
FORMULAS = (
    'theta = acosh((A+D)/2), branch tracked; R = Re[theta B / sinh(theta)]',
    'z_series = B = -1/Y12 for a reciprocal pi model; R = Re(B)',
    'z_series = 2 Z0 (1-S21)/S21; R = Re(z_series)')


def finite(z):
    return math.isfinite(z.real) and math.isfinite(z.imag)


def parse_touchstone(text):
    """Full 2-port single-ended S, RI/MA/DB; legacy or selected TS 2.0 syntax.
    Equal positive real references only. Explicit rejection of unsupported data.
    Returns {'z0':float,'rows':[(f,[S11,S12,S21,S22])], 'format':str}.
    """
    unit, parameter, fmt, z0 = 'GHZ', 'S', 'MA', 50.0
    version, order, refs, count = '1.0', '21_12', None, None
    tokens = []
    options = False
    network = True
    for line_number, raw in enumerate(text.lstrip('\ufeff').splitlines(), 1):
        line = raw.split('!', 1)[0].strip()
        if not line:
            continue
        if line.startswith('#'):
            if options or tokens:
                raise ValueError('Unexpected option line at line %d.' % line_number)
            fields = line[1:].upper().split()
            if len(fields) > 5:
                raise ValueError('Per-port option-line references are unsupported. Export equal real references.')
            fields += ['GHZ', 'S', 'MA', 'R', '50'][len(fields):]
            unit, parameter, fmt = fields[:3]
            if fields[3] != 'R':
                raise ValueError('Reference option must be R.')
            z0 = float(fields[4])
            options = True
            continue
        if line.startswith('['):
            if ']' not in line:
                raise ValueError('Malformed keyword at line %d.' % line_number)
            key, value = line[1:].split(']', 1)
            key, value = key.strip().lower(), value.strip()
            if key == 'version':
                version = value
                if version != '2.0':
                    raise ValueError('Only legacy Touchstone and version 2.0 are supported.')
                network = False
            elif key == 'number of ports':
                if int(value) != 2:
                    raise ValueError('This viewer requires exactly two ports.')
            elif key == 'two-port data order':
                order = value.upper()
                if order not in ('21_12', '12_21'):
                    raise ValueError('Unsupported two-port order.')
            elif key == 'number of frequencies':
                count = int(value)
            elif key == 'reference':
                refs = [float(v) for v in value.split()]
                if len(refs) != 2:
                    raise ValueError('Put both reference values on the [Reference] line.')
            elif key == 'matrix format':
                if value.lower() != 'full':
                    raise ValueError('Export a full matrix, not triangular data.')
            elif key == 'network data':
                network = True
            elif key == 'end':
                network = False
            elif key == 'number of noise frequencies' and int(value) == 0:
                pass
            else:
                raise ValueError('Unsupported keyword [%s]. Noise and mixed-mode data are not supported.' % key)
            continue
        if not network:
            raise ValueError('Unexpected data outside [Network Data].')
        try:
            tokens.extend(float(v.replace('D', 'E').replace('d', 'e')) for v in line.split())
        except ValueError:
            raise ValueError('Non-numeric data at line %d.' % line_number) from None
    if refs:
        if any(not math.isfinite(r) or r <= 0 for r in refs) or refs[0] != refs[1]:
            raise ValueError('Unequal/invalid references. Re-export or renormalize to equal positive real Z0.')
        z0 = refs[0]
    if not math.isfinite(z0) or z0 <= 0:
        raise ValueError('Reference impedance must be positive and finite.')
    units = {'HZ': 1, 'KHZ': 1e3, 'MHZ': 1e6, 'GHZ': 1e9}
    if unit not in units or parameter != 'S' or fmt not in ('RI', 'MA', 'DB'):
        raise ValueError('Expected S data in Hz/kHz/MHz/GHz and RI/MA/DB format.')
    if not tokens or len(tokens) % 9:
        raise ValueError('Incomplete two-port record (9 numbers expected). Noise data are unsupported.')
    if any(not math.isfinite(v) for v in tokens):
        raise ValueError('Input contains NaN or infinity.')
    rows, previous = [], -1.0
    for pos in range(0, len(tokens), 9):
        record = tokens[pos:pos+9]
        f = record[0] * units[unit]
        if f < 0 or f <= previous:
            raise ValueError('Frequencies must be nonnegative and strictly increasing. Check for noise data.')
        previous = f
        values = []
        for a, b in zip(record[1::2], record[2::2]):
            if fmt == 'RI':
                z = complex(a, b)
            else:
                if fmt == 'MA' and a < 0:
                    raise ValueError('Magnitude cannot be negative.')
                z = cmath.rect(10**(a/20) if fmt == 'DB' else a, math.radians(b))
            if not finite(z):
                raise ValueError('Nonfinite S parameter after conversion.')
            values.append(z)
        s = [values[0], values[2], values[1], values[3]] if order == '21_12' else values
        rows.append((f, s))
    if count is not None and count != len(rows):
        raise ValueError('[Number of Frequencies] does not match the data.')
    return {'z0': z0, 'rows': rows, 'format': fmt, 'version': version}


def s_to_abcd(s, z0):
    s11, s12, s21, s22 = s
    if abs(s21) < 1e-14:
        raise ValueError('S21 is zero or too small for stable ABCD conversion.')
    return (
        ((1+s11)*(1-s22)+s12*s21)/(2*s21),
        z0*((1+s11)*(1+s22)-s12*s21)/(2*s21),
        ((1-s11)*(1-s22)-s12*s21)/(2*z0*s21),
        ((1-s11)*(1+s22)+s12*s21)/(2*s21))


def abcd_to_s(t, z0):
    a, b, c, d = t
    den = a+b/z0+c*z0+d
    return [(a+b/z0-c*z0-d)/den, 2*(a*d-b*c)/den,
            2/den, (-a+b/z0-c*z0+d)/den]


def passive_min_eigenvalue(s):
    """Minimum eigenvalue of Hermitian I-S^H S for equal real references."""
    a, b, c, d = s
    h11, h22 = 1-abs(a)**2-abs(c)**2, 1-abs(b)**2-abs(d)**2
    h12 = -(a.conjugate()*b+c.conjugate()*d)
    return ((h11+h22)-math.sqrt((h11-h22)**2+4*abs(h12)**2))/2


def theta_branch(x, prediction):
    principal = cmath.acosh(x)
    candidates = []
    for sign in (1, -1):
        base = sign*principal
        k0 = round((prediction.imag-base.imag)/(2*math.pi))
        for k in range(k0-2, k0+3):
            candidate = base+2j*math.pi*k
            if candidate.real >= -1e-10 and candidate.imag >= -1e-10:
                candidates.append(candidate)
    if not candidates:
        raise ValueError('No passive forward-phase candidate for the assumed ordinary line model.')
    return min(candidates, key=lambda t: abs(t-prediction))


def theta_factor(theta):
    if abs(theta) < 1e-4:
        return 1-theta**2/6+7*theta**4/360-31*theta**6/15120
    sh = cmath.sinh(theta)
    if abs(sh) < 1e-12:
        raise ValueError('Propagation singularity: sinh(theta) is near zero. Use adjacent frequencies or fitting.')
    return theta/sh


def extract(data, mode=0, length_m=.05, delay_s=0):
    if not math.isfinite(length_m) or length_m <= 0:
        raise ValueError('Length must be positive and finite.')
    if not math.isfinite(delay_s) or delay_s < 0:
        raise ValueError('Seed delay must be nonnegative and finite.')
    z0, result, history = data['z0'], [], []
    for index, (f, s) in enumerate(data['rows']):
        row = {'index': index+1, 'f': f, 's': s, 'r': None, 'x': None,
               'flags': [], 'abcd': None, 'theta': None, 'g': None, 'residual': None}
        flags = row['flags']
        try:
            t = s_to_abcd(s, z0)
            if not all(finite(v) for v in t):
                raise ValueError('Nonfinite ABCD values.')
            row['abcd'] = t
            a, b, c, d = t
            if passive_min_eigenvalue(s) < -1e-7:
                flags.append('Nonpassive terminal data')
            reciprocal = abs(s[1]-s[2])/max(abs(s[1]), abs(s[2]), 1e-12)
            if reciprocal > 1e-3:
                flags.append('Not reciprocal')
            if abs(s[2]) < 1e-6:
                flags.append('Very small transmission')
            if mode == 0:
                if f == 0 and abs(c*z0) < 1e-10 and max(abs(a-1),abs(d-1)) < 1e-7:
                    theta, factor = 0j, 1+0j
                    model = (1+0j, b, 0j, 1+0j)
                else:
                    if history:
                        fp, tp = history[-1]
                        prediction = tp * (f/fp) if fp > 0 else complex(tp.real,2*math.pi*f*delay_s)
                        if len(history) >= 2:
                            fpp, tpp = history[-2]
                            prediction = tp+(tp-tpp)*(f-fp)/(fp-fpp)
                    else:
                        prediction = complex(0, 2*math.pi*f*delay_s)
                    theta = theta_branch((a+d)/2, prediction)
                    if history and abs(theta.imag-history[-1][1].imag) > math.pi:
                        flags.append('Sparse phase sampling')
                    factor = theta_factor(theta)
                    sh = cmath.sinh(theta)
                    if abs(theta) < 1e-12:
                        if abs(c*z0) > 1e-7:
                            raise ValueError('Degenerate line representation; use a justified lumped model.')
                        model = (1+0j, b, 0j, 1+0j)
                    else:
                        zc = b/sh
                        if abs(zc) == 0:
                            raise ValueError('Degenerate characteristic impedance.')
                        model = (cmath.cosh(theta), b, sh/zc, cmath.cosh(theta))
                z = factor*b
                y = factor*c
                row['theta'], row['g'] = theta, y.real
                model_s = abcd_to_s(model, z0)
                residual = max(abs(x-y) for x,y in zip(s, model_s))
                row['residual'] = residual
                if residual > 1e-3 or abs(a-d) > 1e-3*max(1,abs(a),abs(d)):
                    flags.append('Uniform-line mismatch')
                if y.real < -1e-10:
                    flags.append('Negative shunt conductance')
                history.append((f, theta))
            elif mode == 1:
                if reciprocal > 1e-3:
                    raise ValueError('Reciprocal pi interpretation does not fit the data.')
                z = b
            else:
                z = 2*z0*(1-s[2])/s[2]
                model_s = abcd_to_s((1,z,0,1),z0)
                residual = max(abs(x-y) for x,y in zip(s,model_s))
                row['residual'] = residual
                if residual > 1e-3:
                    flags.append('Series-only mismatch')
            if not finite(z):
                raise ValueError('Nonfinite extracted impedance.')
            row['r'], row['x'], row['r_per_m'] = z.real, z.imag, z.real/length_m
            if z.real < -1e-10:
                flags.append('Negative resistance')
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            flags.append(str(exc))
        result.append(row)
    return result


def demo_text(fmt='RI'):
    lines = ['! SYNTHETIC uniform 50 mm passive RL line. Not a SIwave field solve.',
             '# Hz S %s R 50' % fmt]
    for f in [0.0]+[10**(3+k/40) for k in range(241)]:
        jw = 2j*math.pi*f
        q = .01+jw*1e-9+.09*jw*1e-8/(.09+jw*1e-8)
        if f == 0:
            t = (1,q,0,1)
        else:
            zp, yp = q/.05, jw*100e-12
            gamma, zc = cmath.sqrt(zp*yp), cmath.sqrt(zp/yp)
            theta = gamma*.05
            t = (cmath.cosh(theta),zc*cmath.sinh(theta),cmath.sinh(theta)/zc,cmath.cosh(theta))
        s = abcd_to_s(t,50)
        values = [f]
        for v in (s[0],s[2],s[1],s[3]):
            if fmt == 'RI':
                values += [v.real,v.imag]
            else:
                magnitude = abs(v)
                values += [20*math.log10(magnitude) if fmt == 'DB' else magnitude,math.degrees(cmath.phase(v))]
        lines.append(' '.join('%.17g'%v for v in values))
    return '\n'.join(lines)+'\n'


def number(v, digits=6):
    if v is None:
        return '--'
    return '%.*g' % (digits, v)


def hz(f):
    for factor, suffix in [(1e9,'GHz'),(1e6,'MHz'),(1e3,'kHz')]:
        if f >= factor:
            return '%s %s'%(number(f/factor),suffix)
    return '%s Hz'%number(f)


class ScopeApp:
    def __init__(self, root):
        self.root = root
        self.data, self.rows, self.selected, self.viewport = None, [], 0, None
        self.job = 0
        self.applied_mode, self.applied_length, self.applied_delay = 0, .05, 0
        self.queue = queue.Queue()
        self.busy = False
        root.title('SIwave R(f) Analyzer - Two-Port S2P')
        root.geometry('1280x850')
        root.minsize(1080,730)
        root.configure(bg=BG)
        self.mode = tk.StringVar(value=MODES[0])
        self.length = tk.StringVar(value='50')
        self.delay = tk.StringVar(value='0')
        self.units = tk.StringVar(value='mOhm')
        self.log_x = tk.BooleanVar(value=True)
        self.log_y = tk.BooleanVar(value=False)
        self.show_x = tk.BooleanVar(value=False)
        self.row_var = tk.StringVar(value='1')
        self.freq_var = tk.StringVar(value='')
        self.filename = tk.StringVar(value='Open a two-port .s2p file, or load the synthetic demo')
        self.status = tk.StringVar(value='READY  |  Standalone Python 3 viewer; no Excel or CSV required')
        self.card_f, self.card_r, self.card_row = tk.StringVar(value='--'),tk.StringVar(value='--'),tk.StringVar(value='--')
        self._style()
        self._layout()
        root.bind('<Left>',lambda e:self.step(-1))
        root.bind('<Right>',lambda e:self.step(1))
        root.bind('<Control-o>',lambda e:self.open_file())
        root.bind('<Configure>',self.root_resized)
        root.after(80,self.poll)

    def _style(self):
        style=ttk.Style()
        style.theme_use('clam')
        style.configure('.',background=BG,foreground=TEXT,font=('Segoe UI',9))
        style.configure('TButton',padding=(7,4),background='#dedede',foreground=TEXT)
        style.map('TButton',background=[('active','#f4f4f4')])
        style.configure('TCombobox',fieldbackground='white',background='#dedede',foreground=TEXT)
        style.map('TCombobox',fieldbackground=[('readonly','white')],foreground=[('readonly',TEXT)])
        style.configure('TEntry',fieldbackground='white',foreground=TEXT)
        style.configure('TCheckbutton',background=BG,foreground=TEXT)
        style.configure('TLabelframe',background=BG)
        style.configure('TLabelframe.Label',background=BG,foreground=TEXT,font=('Segoe UI',9,'bold'))
        style.configure('Treeview',background='white',fieldbackground='white',foreground=TEXT,rowheight=23,font=('Consolas',9))
        style.configure('Treeview.Heading',background='#dedede',foreground=TEXT,font=('Segoe UI',9))
        style.map('Treeview',background=[('selected','#d9eaf5')],foreground=[('selected','#111111')])
        self.root.option_add('*TCombobox*Listbox.background','white')
        self.root.option_add('*TCombobox*Listbox.foreground',TEXT)

    def label(self,parent,text,**kw):
        return tk.Label(parent,text=text,bg=parent.cget('bg'),fg=kw.pop('fg',TEXT),**kw)

    def _layout(self):
        self.secondary=tk.StringVar(value='Impedance phase')
        menu=tk.Frame(self.root,bg=BG,bd=1,relief='groove')
        menu.pack(fill='x',padx=6,pady=(5,0))
        self.label(menu,'SIwave R(f)',font=('Segoe UI',10,'bold')).pack(side='left',padx=8)
        for title,command in [('Open S2P',self.open_file),('Demo',self.demo),('Recalculate',self.recalculate),('Export CSV',self.export),('Math / help',self.help)]:
            ttk.Button(menu,text=title,command=command).pack(side='left',padx=2,pady=3)
        self.label(menu,'Two-port analysis',fg=MUTED).pack(side='right',padx=10)

        inputs=ttk.LabelFrame(self.root,text='Input and extraction',padding=8)
        inputs.pack(fill='x',padx=6,pady=5)
        for col,title in enumerate(('Extraction model','Line length (mm)','Seed delay (ns)','Frequency axis','Resistance units')):
            ttk.Label(inputs,text=title).grid(row=0,column=col,padx=6,sticky='w')
        model=ttk.Combobox(inputs,textvariable=self.mode,values=MODES,state='readonly',width=28)
        model.grid(row=1,column=0,padx=6,sticky='w');model.bind('<<ComboboxSelected>>',lambda e:self.recalculate())
        ttk.Entry(inputs,textvariable=self.length,width=13).grid(row=1,column=1,padx=6,sticky='w')
        ttk.Entry(inputs,textvariable=self.delay,width=13).grid(row=1,column=2,padx=6,sticky='w')
        ttk.Checkbutton(inputs,text='Log sweep',variable=self.log_x,command=self.reset_view).grid(row=1,column=3,padx=6,sticky='w')
        unit=ttk.Combobox(inputs,textvariable=self.units,values=('mOhm','Ohm'),state='readonly',width=10)
        unit.grid(row=1,column=4,padx=6,sticky='w');unit.bind('<<ComboboxSelected>>',lambda e:self.refresh())
        ttk.Button(inputs,text='Apply settings',command=self.recalculate).grid(row=1,column=5,padx=12)
        inputs.columnconfigure(6,weight=1)
        ttk.Label(inputs,textvariable=self.filename,foreground=MUTED).grid(row=2,column=0,columnspan=7,padx=6,pady=(7,0),sticky='w')

        readout=ttk.LabelFrame(self.root,text='Readout',padding=(8,5))
        readout.pack(fill='x',padx=6,pady=(0,5))
        for col,(title,var) in enumerate((('Frequency',self.card_f),('Series resistance',self.card_r),('Selected row',self.card_row))):
            ttk.Label(readout,text=title).grid(row=0,column=col*2,padx=(5,8),sticky='w')
            tk.Label(readout,textvariable=var,bg='white',fg=TEXT,relief='sunken',bd=1,font=('Consolas',13),width=23,anchor='w',padx=6).grid(row=0,column=col*2+1,padx=(0,14),sticky='ew')
            readout.columnconfigure(col*2+1,weight=1)

        self.formula=tk.StringVar(value=FORMULAS[0])
        tk.Label(self.root,textvariable=self.formula,bg=BG,fg=MUTED,font=('Consolas',9),anchor='w').pack(fill='x',padx=14,pady=(0,3))
        footer=tk.Label(self.root,textvariable=self.status,bg='#dedede',fg=TEXT,font=('Consolas',9),anchor='w',bd=1,relief='sunken')
        footer.pack(side='bottom',fill='x',padx=6,pady=(4,5))
        paned=tk.PanedWindow(self.root,orient='horizontal',bg=BG,sashwidth=7,bd=0)
        paned.pack(fill='both',expand=True,padx=6)
        left=tk.Frame(paned,bg=BG)
        right=tk.Frame(paned,bg=BG,width=315)
        paned.add(left,minsize=630,stretch='always');paned.add(right,minsize=290,stretch='never')

        plotbar=tk.Frame(left,bg=BG,bd=1,relief='groove')
        plotbar.pack(fill='x')
        self.label(plotbar,'Oscilloscope',font=('Segoe UI',9,'bold')).pack(side='left',padx=8)
        ttk.Checkbutton(plotbar,text='Log R',variable=self.log_y,command=self.reset_view).pack(side='left',padx=6)
        self.label(plotbar,'Lower trace').pack(side='left',padx=(10,4))
        lower=ttk.Combobox(plotbar,textvariable=self.secondary,values=('Impedance phase','Reactance X'),state='readonly',width=18)
        lower.pack(side='left');lower.bind('<<ComboboxSelected>>',lambda e:self.draw())
        ttk.Button(plotbar,text='Reset range',command=self.reset_view).pack(side='right',padx=4,pady=3)
        self.canvas=tk.Canvas(left,bg=BG,highlightthickness=0,height=260)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',lambda e:self.draw())
        self.canvas.bind('<Button-1>',self.click_plot)
        self.canvas.bind('<MouseWheel>',self.zoom)
        self.canvas.bind('<Button-4>',lambda e:self.zoom(e,1))
        self.canvas.bind('<Button-5>',lambda e:self.zoom(e,-1))
        self.canvas.bind('<ButtonPress-3>',self.pan_start)
        self.canvas.bind('<B3-Motion>',self.pan_move)
        hint=self.label(left,'Click: cursor  |  Wheel: zoom  |  Right-drag: pan  |  Arrows: previous / next',fg=MUTED,font=('Consolas',9),anchor='w')
        hint.pack(fill='x',pady=(2,4))
        table_frame=ttk.LabelFrame(left,text='Frequency rows - select a row to inspect',padding=3)
        table_frame.pack(fill='x')
        self.table=ttk.Treeview(table_frame,columns=('row','f','r','x','flag'),show='headings',height=5)
        for col,title,width in [('row','Row',45),('f','Frequency (Hz)',125),('r','R (Ohm)',125),('x','X (Ohm)',125),('flag','Checks',200)]:
            self.table.heading(col,text=title);self.table.column(col,width=width,stretch=col=='flag',anchor='w')
        self.table.pack(side='left',fill='x',expand=True)
        scroll=ttk.Scrollbar(table_frame,orient='vertical',command=self.table.yview)
        scroll.pack(side='right',fill='y');self.table.configure(yscrollcommand=scroll.set)
        self.table.tag_configure('warning',foreground='#875900');self.table.tag_configure('invalid',foreground=RED)
        self.table.bind('<<TreeviewSelect>>',self.table_selected)
        self.canvas.pack_forget();hint.pack_forget();table_frame.pack_forget()
        table_frame.pack(side='bottom',fill='x')
        hint.pack(side='bottom',fill='x',pady=(2,4))
        self.canvas.pack(fill='both',expand=True)

        control=ttk.LabelFrame(right,text='Cursor control',padding=8)
        control.pack(fill='x',pady=(0,6))
        ttk.Label(control,text='Row (1-based)').grid(row=0,column=0,sticky='w')
        rowentry=ttk.Entry(control,textvariable=self.row_var,width=12)
        rowentry.grid(row=0,column=1,padx=5,sticky='ew');rowentry.bind('<Return>',lambda e:self.go_row())
        ttk.Button(control,text='Go',command=self.go_row).grid(row=0,column=2)
        ttk.Button(control,text='< Previous',command=lambda:self.step(-1)).grid(row=1,column=0,pady=5,sticky='ew')
        ttk.Button(control,text='Next >',command=lambda:self.step(1)).grid(row=1,column=1,pady=5,sticky='ew')
        ttk.Label(control,text='Frequency (Hz)').grid(row=2,column=0,sticky='w')
        freqentry=ttk.Entry(control,textvariable=self.freq_var,width=12)
        freqentry.grid(row=2,column=1,padx=5,sticky='ew');freqentry.bind('<Return>',lambda e:self.go_frequency())
        ttk.Button(control,text='Nearest',command=self.go_frequency).grid(row=2,column=2)
        control.columnconfigure(1,weight=1)

        box=ttk.LabelFrame(right,text='Selected row / original S data',padding=5)
        box.pack(fill='both',expand=True)
        copy=ttk.Button(box,text='Copy row readout',command=self.copy_row)
        copy.pack(side='bottom',fill='x',pady=(5,0))
        self.details=tk.Text(box,bg='white',fg=TEXT,relief='sunken',bd=1,wrap='word',font=('Consolas',9),width=32,height=12)
        detailsscroll=ttk.Scrollbar(box,orient='vertical',command=self.details.yview)
        detailsscroll.pack(side='right',fill='y');self.details.pack(side='left',fill='both',expand=True)
        self.details.configure(yscrollcommand=detailsscroll.set,state='disabled')
        ttk.Label(right,text='R is model-dependent. Match the conductor,\nreturn path and Q3D reduction.',foreground='#705300').pack(fill='x',pady=(5,0))

    def root_resized(self,event):
        if event.widget is self.root and hasattr(self,'table'):
            height=3 if self.root.winfo_height()<800 else 5
            if int(self.table.cget('height')) != height:
                self.table.configure(height=height)
                if self.rows:self.root.after(50,lambda:self.table.see(str(self.selected)))

    def configuration(self):
        return MODES.index(self.mode.get()),float(self.length.get())/1000,float(self.delay.get())*1e-9

    def launch(self,work):
        self.job += 1
        job=self.job
        self.busy=True
        self.status.set('PROCESSING  |  Parsing complex S and checking the selected model...')
        def task():
            try:
                self.queue.put((job,work(),None))
            except Exception as exc:
                self.queue.put((job,None,str(exc)))
        threading.Thread(target=task,daemon=True).start()

    def poll(self):
        try:
            while True:
                job,value,error=self.queue.get_nowait()
                if job != self.job:
                    continue
                self.busy=False
                if error:
                    self.status.set('LOAD / CALCULATION ERROR  |  '+error)
                    messagebox.showerror('Cannot process this input',error)
                    continue
                self.data,self.rows,name,self.applied_mode,self.applied_length,self.applied_delay=value
                self.filename.set(name+'  |  %s  |  Z0 = %s Ohm  |  %d rows'%(self.data['format'],number(self.data['z0']),len(self.rows)))
                self.viewport=None
                self.selected=min(self.selected,len(self.rows)-1)
                self.populate()
                self.refresh()
        except queue.Empty:
            pass
        self.root.after(80,self.poll)

    def load(self,path):
        try:
            mode,length,delay=self.configuration()
        except ValueError:
            messagebox.showerror('Settings','Enter numeric length and delay.'); return
        def work():
            data=parse_touchstone(Path(path).read_text(encoding='utf-8-sig'))
            return data,extract(data,mode,length,delay),str(Path(path).name),mode,length,delay
        self.launch(work)

    def open_file(self):
        path=filedialog.askopenfilename(title='Open two-port S parameters',filetypes=[('Two-port Touchstone','*.s2p *.ts'),('All files','*.*')])
        if path:self.load(path)

    def demo(self):
        self.mode.set(MODES[0]); self.length.set('50'); self.delay.set('0')
        self.launch(lambda:(lambda d:(d,extract(d),'SYNTHETIC DEMO - passive uniform 50 mm line',0,.05,0))(parse_touchstone(demo_text())))

    def recalculate(self):
        if not self.data:
            self.formula.set(FORMULAS[MODES.index(self.mode.get())]);return
        try:
            mode,length,delay=self.configuration()
        except ValueError:
            messagebox.showerror('Settings','Enter numeric length and delay.');return
        data=self.data
        name=self.filename.get().split('  |')[0]
        self.launch(lambda:(data,extract(data,mode,length,delay),name,mode,length,delay))

    def populate(self):
        self.formula.set(FORMULAS[self.applied_mode])
        self.table.delete(*self.table.get_children())
        for row in self.rows:
            flags='; '.join(row['flags']) or 'Numeric checks pass'
            self.table.insert('', 'end', iid=str(row['index']-1),values=(row['index'],number(row['f'],10),number(row['r'],10),number(row['x'],10),flags),tags=('invalid' if row['r'] is None else 'warning' if row['flags'] else 'ok',))

    def refresh(self):
        self.inspect();self.draw()

    def inspect(self):
        if not self.rows:return
        row=self.rows[self.selected]
        scale=1000 if self.units.get()=='mOhm' else 1
        self.card_f.set(hz(row['f']))
        self.card_r.set('%s %s'%(number(None if row['r'] is None else row['r']*scale,8),self.units.get()))
        self.card_row.set('%d / %d'%(row['index'],len(self.rows)))
        self.row_var.set(str(row['index']))
        self.table.selection_set(str(self.selected));self.table.see(str(self.selected))
        text=['ROW %d  |  %s'%(row['index'],hz(row['f'])), 'f = %.12g Hz'%row['f'], '',
              'Model: '+MODES[self.applied_mode],'R = %s Ohm'%number(row['r'],12),
              'R / length = %s Ohm/m'%number(row.get('r_per_m'),12),'X = %s Ohm'%number(row['x'],12),'']
        if row['theta'] is not None:
            text += ['theta = '+self.complex_text(row['theta']), 'ell G = %s S'%number(row['g'],10)]
        if row['residual'] is not None:text += ['S reconstruction max |error| = %s'%number(row['residual'],5)]
        text += ['', 'ROW CHECKS']+(['- '+f for f in row['flags']] or ['Numeric checks pass.'])
        text += ['', 'Checks cannot prove uniform geometry or isolate internal copper loss.', '', 'SOURCE S (real + j imaginary)']
        for name,v in zip(('S11','S12','S21','S22'),row['s']):
            text += [name+'  '+self.complex_text(v),'  |S|=%s, phase=%s deg'%(number(abs(v),7),number(math.degrees(cmath.phase(v)),7))]
        if row['abcd']:
            text += ['', 'ABCD  (B: Ohm, C: Siemens)']
            text += [name+'  '+self.complex_text(v) for name,v in zip('ABCD',row['abcd'])]
        self.details.configure(state='normal');self.details.delete('1.0','end');self.details.insert('1.0','\n'.join(text));self.details.configure(state='disabled')
        invalid=sum(r['r'] is None for r in self.rows)
        warning=sum(bool(r['flags']) and r['r'] is not None for r in self.rows)
        seed='Delay seed supplied' if self.applied_delay>0 else 'Low-phase seed; verify initial delay'
        self.status.set(('PROCESSING - previous result  |  ' if self.busy else '')+'%d rows  |  %d invalid  |  %d flagged  |  %s  |  Geometry/Q3D matching required'%(len(self.rows),invalid,warning,seed))

    @staticmethod
    def complex_text(v):
        return '%.7g %+.7gj'%(v.real,v.imag)

    def table_selected(self,event):
        values=self.table.selection()
        if values:
            n=int(values[0])
            if n != self.selected:
                self.selected=n;self.refresh()

    def step(self,delta):
        if self.rows:
            self.selected=max(0,min(len(self.rows)-1,self.selected+delta));self.refresh()

    def go_row(self):
        try:
            n=int(self.row_var.get())-1
            if not 0<=n<len(self.rows):raise ValueError()
            self.selected=n;self.refresh()
        except ValueError:messagebox.showerror('Row','Enter a row number between 1 and %d.'%len(self.rows))

    def go_frequency(self):
        try:
            f=float(self.freq_var.get())
            if not math.isfinite(f) or f<0:raise ValueError()
            if self.rows:
                self.selected=min(range(len(self.rows)),key=lambda i:abs(self.rows[i]['f']-f));self.refresh()
        except ValueError:messagebox.showerror('Frequency','Enter a nonnegative frequency in Hz (for example 1e6).')

    def copy_row(self):
        if self.rows:
            self.root.clipboard_clear();self.root.clipboard_append(self.details.get('1.0','end-1c'))

    def reset_view(self):
        self.viewport=None;self.refresh()

    def plot_points(self):
        positive=[r['f'] for r in self.rows if r['f']>0]
        dc_x=math.log10(min(positive))-1 if positive else -1
        self.dc_x=dc_x
        traces=[[],[]]
        for i,r in enumerate(self.rows):
            x=math.log10(r['f']) if self.log_x.get() and r['f']>0 else dc_x if self.log_x.get() else r['f']
            for j,k in enumerate(('r','x')):
                y=r[k]
                if y is None or (self.log_y.get() and y<=0):
                    traces[j].append((i,x,None));continue
                traces[j].append((i,x,math.log10(y) if self.log_y.get() else y))
        return traces

    def draw(self):
        c=self.canvas;c.delete('all')
        w,h=c.winfo_width(),c.winfo_height()
        if w<60 or h<60:return
        if not self.rows:
            c.create_rectangle(64,12,w-15,max(13,h-42),fill='#000000',outline='#555555')
            c.create_text(w/2,h/2,text='Open a two-port S2P file or load Demo',fill='#ffffda',font=('Consolas',12));return
        traces=self.plot_points()
        valid=[(x,y) for i,x,y in traces[0] if y is not None]
        if not valid:
            c.create_text(w/2,h/2,text='No positive R points on this log scale.\nDisable Log R to inspect nonpositive values.',fill=RED,font=('Consolas',11));return
        if self.viewport is None:
            xmin,xmax=min(x for x,y in valid),max(x for x,y in valid)
            ymin,ymax=min(y for x,y in valid),max(y for x,y in valid)
            dx=xmax-xmin or 1;dy=ymax-ymin or max(1e-6,abs(ymin)*.2)
            self.viewport=(xmin-.015*dx,xmax+.015*dx,ymin-.08*dy,ymax+.08*dy)
        xmin,xmax,ymin,ymax=self.viewport
        left,right=70,w-16
        top=14;bottom=max(top+35,(h-48)/2)
        top2=bottom+42;bottom2=max(top2+35,h-38)
        self.rect=(left,top,right,bottom)
        scale=1000 if self.units.get()=='mOhm' else 1

        lower=[]
        for i,row in enumerate(self.rows):
            x=traces[0][i][1]
            if row['r'] is None:
                lower.append((i,x,None));continue
            y=math.degrees(math.atan2(row['x'],row['r'])) if self.secondary.get()=='Impedance phase' else row['x']*scale
            lower.append((i,x,y))
        lows=[y for i,x,y in lower if y is not None and xmin<=x<=xmax]
        lowmin,lowmax=(min(lows),max(lows)) if lows else (0,1)
        delta=lowmax-lowmin or max(1,abs(lowmin)*.1)
        lowmin-=.08*delta;lowmax+=.08*delta

        def draw_axis(trace,t,b,lo,hi,label,is_r=False):
            c.create_rectangle(left,t,right,b,fill='black',outline='#545454')
            def xy(x,y):return left+(x-xmin)/(xmax-xmin)*(right-left),b-(y-lo)/(hi-lo)*(b-t)
            for n in range(41):
                px=left+(right-left)*n/40
                c.create_line(px,t,px,b,fill='#737522' if n%4==0 else '#30320e',width=1)
            for n in range(21):
                py=t+(b-t)*n/20
                c.create_line(left,py,right,py,fill='#737522' if n%5==0 else '#30320e',width=1)
            for n in range(5):
                yy=t+(b-t)*n/4
                value=hi-(hi-lo)*n/4
                if is_r:value=(10**value if self.log_y.get() else value)*scale
                c.create_text(left-5,yy,text=number(value,4),anchor='e',fill=TEXT,font=('Consolas',8))
            c.create_text(14,(t+b)/2,text=label,angle=90,fill=TEXT,font=('Segoe UI',9))
            for n in range(6):
                xx=left+(right-left)*n/5
                value=xmin+(xmax-xmin)*n/5
                text=hz(10**value) if self.log_x.get() else hz(value)
                if self.log_x.get() and any(r['f']==0 for r in self.rows) and value<=self.dc_x+.5:text='DC'
                c.create_text(xx,b+11,text=text,fill=TEXT,font=('Consolas',8),anchor='w' if n==0 else 'e' if n==5 else 'center')
            previous=None
            for i,x,y in trace:
                if y is None:previous=None;continue
                px,py=xy(x,y)
                inside=left<=px<=right and t<=py<=b
                if self.log_x.get() and i>0 and self.rows[i-1]['f']==0:previous=None
                if inside and previous:c.create_line(*previous,px,py,fill='#ffffc8',width=1)
                if inside and (self.rows[i]['f']==0 or len(trace)==1):c.create_oval(px-2,py-2,px+2,py+2,fill='#ffffc8',outline='')
                previous=(px,py) if inside else None
            i,x,y=trace[self.selected]
            if y is not None:
                px,py=xy(x,y)
                if left<=px<=right:
                    c.create_line(px,t,px,b,fill='#d5de8b',dash=(3,4))
                    if t<=py<=b:c.create_oval(px-3,py-3,px+3,py+3,fill='white',outline='#d5de8b')

        draw_axis(traces[0],top,bottom,ymin,ymax,'R ('+self.units.get()+')',True)
        draw_axis(lower,top2,bottom2,lowmin,lowmax,'Phase (deg)' if self.secondary.get()=='Impedance phase' else 'X ('+self.units.get()+')')
        c.create_text((left+right)/2,h-6,text='Frequency (Hz) - DC shown separately on a log sweep',fill=MUTED,font=('Segoe UI',8))
        hidden=sum(row['r'] is not None and row['r']<=0 for row in self.rows) if self.log_y.get() else 0
        if hidden:c.create_text(right,top+8,text='%d nonpositive R hidden by log scale'%hidden,fill='#ffffc8',font=('Consolas',8),anchor='e')

    def click_plot(self,e):
        if not self.rows or not self.viewport:return
        l,t,r,b=self.rect
        if not l<=e.x<=r:return
        target=self.viewport[0]+(e.x-l)/(r-l)*(self.viewport[1]-self.viewport[0])
        trace=self.plot_points()[0]
        self.selected=min(range(len(trace)),key=lambda i:abs(trace[i][1]-target));self.refresh()

    def zoom(self,e,direction=None):
        if not self.viewport:return
        direction=direction if direction is not None else (1 if e.delta>0 else -1)
        l,t,r,b=self.rect
        xmin,xmax,ymin,ymax=self.viewport
        ratio=max(0,min(1,(e.x-l)/(r-l)))
        center=xmin+(xmax-xmin)*ratio
        factor=.8 if direction>0 else 1.25
        self.viewport=(center+(xmin-center)*factor,center+(xmax-center)*factor,ymin,ymax);self.draw()

    def pan_start(self,e):self.pan_origin=(e.x,self.viewport)

    def pan_move(self,e):
        origin,view=getattr(self,'pan_origin',(0,None))
        if not view:return
        l,t,r,b=self.rect
        dx=(e.x-origin)/(r-l)*(view[1]-view[0])
        self.viewport=(view[0]-dx,view[1]-dx,view[2],view[3]);self.draw()

    def export(self):
        if not self.rows:
            messagebox.showinfo('Export','Open an S2P file first.');return
        if self.busy:
            messagebox.showinfo('Export','Wait for the current calculation.');return
        path=filedialog.asksaveasfilename(defaultextension='.csv',initialfile='rf_scope_export.csv',filetypes=[('CSV','*.csv')])
        if not path:return
        try:
            with open(path,'w',newline='',encoding='utf-8') as f:
                writer=csv.writer(f)
                writer.writerow(['row','frequency_Hz','model','R_ohm','X_ohm','R_ohm_per_m','ell_G_S','S_reconstruction_abs_error','flags'])
                for row in self.rows:
                    writer.writerow([row['index'],row['f'],MODES[self.applied_mode],row['r'],row['x'],row.get('r_per_m'),row['g'],row['residual'],'; '.join(row['flags'])])
            self.status.set('EXPORTED  |  '+path)
        except OSError as exc:messagebox.showerror('Export failed',str(exc))

    def help(self):
        win=tk.Toplevel(self.root);win.title('Math and model requirements');win.geometry('780x580');win.configure(bg=PANEL)
        box=tk.Text(win,bg=PANEL,fg=TEXT,wrap='word',font=('Consolas',11),padx=18,pady=16)
        box.pack(fill='both',expand=True)
        box.insert('1.0',
            'UNIFORM LINE / RLGC\n\n'+FORMULAS[0]+
            '\n\nAssumes a uniform, reciprocal, ordinary passive line with one dominant mode. '
            'The result includes the modeled conductor AND return path. It does not isolate an internal trace. '
            'Use low-frequency data or a known seed delay to choose the initial acosh branch. '
            'The displayed checks cannot prove uniqueness or uniform geometry.\n\n'
            'LUMPED PI / SERIES ARM\n\nR = Re(B). The terminal pi equivalent is exact for reciprocal data, '
            'but B is a physical conductor impedance only if that circuit decomposition is justified.\n\n'
            'SERIES-ONLY FIXTURE\n\n'+FORMULAS[2]+
            '\n\nAssumes no shunt branches. A mismatch warning means the ideal fixture does not fit.\n\n'
            'SUPPORTED INPUT\n\nFull two-port single-ended S, RI/MA/DB, equal positive real references. '
            'Legacy Touchstone or the documented limited 2.0 subset. Noise, mixed-mode, triangular, unequal-reference '
            'and complex-reference files are rejected. Negative results remain visible.\n\n'
            'DC\n\nFor negligible shunt leakage, the true DC point uses R = Re(B). '
            'Log frequency places DC in a separate labeled left-hand position; it is not a positive-frequency estimate.\n\n'
            'PAPERS\n\nFang et al. 2018: https://doi.org/10.1371/journal.pone.0205072\n'
            'Degerstrom et al. 2008: https://doi.org/10.1109/EPEP.2008.4675881\n'
            'Eisenstadt & Eo 1992: https://doi.org/10.1109/33.159877\n\n'
            'RUNNING\n\nRequires desktop Python 3.10+ with Tkinter. No pip packages required. '
            'This standalone GUI is not an IronPython/SIwave embedded script.')
        box.configure(state='disabled')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file',nargs='?')
    parser.add_argument('--demo',action='store_true')
    args=parser.parse_args()
    root=tk.Tk();app=ScopeApp(root)
    if args.demo:app.demo()
    elif args.file:app.load(args.file)
    root.mainloop()


if __name__=='__main__':
    main()

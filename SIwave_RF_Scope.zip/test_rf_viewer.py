"""Independent analytic checks; run python -m unittest test_rf_viewer -v."""
import cmath
import math
import unittest
import siwave_rf_viewer as m


def file_from_s(rows, z0=50, fmt='RI', order='21_12', v2=False):
    text=[]
    if v2:text += ['[Version] 2.0']
    text += ['# Hz S %s R %g'%(fmt,z0)]
    if v2:text += ['[Number of Ports] 2','[Two-Port Data Order] '+order,'[Number of Frequencies] %d'%len(rows),'[Reference] %g %g'%(z0,z0),'[Matrix Format] Full','[Network Data]']
    for f,s in rows:
        numbers=[f]
        for z in ([s[0],s[2],s[1],s[3]] if order=='21_12' else s):
            numbers += [z.real,z.imag] if fmt=='RI' else [20*math.log10(abs(z)) if fmt=='DB' else abs(z),math.degrees(cmath.phase(z))]
        text += [' '.join('%.17g'%v for v in numbers)]
    if v2:text += ['[End]']
    return '\n'.join(text)


class MathTests(unittest.TestCase):
    def test_demo_analytic_rlgc_all_formats(self):
        for fmt in ('RI','MA','DB'):
            rows=m.extract(m.parse_touchstone(m.demo_text(fmt)))
            for row in rows:
                w=2*math.pi*row['f']
                target=.01+.09*(w*1e-8)**2/(.09**2+(w*1e-8)**2)
                self.assertIsNotNone(row['r'])
                self.assertLess(abs(row['r']-target)/target,1e-8)
                self.assertLess(abs(row['g']),1e-8)

    def test_passive_long_line_branch_tracking(self):
        length=1.5
        data=[]
        for k in range(601):
            f=10**(6+k/200)
            z=.8+2j*math.pi*f*250e-9
            y=2j*math.pi*f*100e-12
            gamma,zc=cmath.sqrt(z*y),cmath.sqrt(z/y)
            theta=gamma*length
            s=m.abcd_to_s((cmath.cosh(theta),zc*cmath.sinh(theta),cmath.sinh(theta)/zc,cmath.cosh(theta)),50)
            data.append((f,s))
        rows=m.extract({'z0':50,'rows':data},length_m=length)
        for row in rows:
            self.assertIsNotNone(row['r'])
            self.assertLess(abs(row['r']-1.2),1e-7)
        self.assertGreater(rows[-1]['theta'].imag,14*math.pi)

    def test_delay_seed_high_frequency_start(self):
        length,f=1.5,5e8
        zp=.8+2j*math.pi*f*250e-9
        yp=2j*math.pi*f*100e-12
        gamma,zc=cmath.sqrt(zp*yp),cmath.sqrt(zp/yp)
        theta=gamma*length
        s=m.abcd_to_s((cmath.cosh(theta),zc*cmath.sinh(theta),cmath.sinh(theta)/zc,cmath.cosh(theta)),50)
        row=m.extract({'z0':50,'rows':[(f,s)]},length_m=length,delay_s=7.5e-9)[0]
        self.assertAlmostEqual(row['r'],1.2,places=7)

    def test_order_nonsymmetric_two_port(self):
        s=[.1+.02j,.2-.03j,.3+.05j,-.15+.07j]
        for order in ('21_12','12_21'):
            data=m.parse_touchstone(file_from_s([(1e6,s)],order=order,v2=True))
            self.assertEqual(data['rows'][0][1],s)

    def test_series_all_reference_values(self):
        z=.012+1.2j
        for z0 in (25,50,75):
            s=m.abcd_to_s((1,z,0,1),z0)
            row=m.extract(m.parse_touchstone(file_from_s([(1e6,s)],z0)),mode=2)[0]
            self.assertAlmostEqual(row['r'],z.real,places=10)
            self.assertAlmostEqual(row['x'],z.imag,places=10)
            self.assertFalse(row['flags'])

    def test_pi_arm_and_wrong_series_warning(self):
        z=.02+2j
        y1,y2=.001+.03j,.002+.07j
        t=(1+z*y2,z,y1+y2+y1*z*y2,1+y1*z)
        s=m.abcd_to_s(t,50)
        data=m.parse_touchstone(file_from_s([(1e7,s)]))
        pi=m.extract(data,mode=1)[0]
        self.assertAlmostEqual(pi['r'],z.real,places=10)
        self.assertIn('Series-only mismatch',m.extract(data,mode=2)[0]['flags'])
        self.assertIn('Uniform-line mismatch',m.extract(data,mode=0)[0]['flags'])

    def test_singular_row_does_not_destroy_next_row(self):
        s=m.abcd_to_s((1,.1,0,1),50)
        rows=m.extract({'z0':50,'rows':[(1,[0j,0j,0j,0j]),(2,s)]},mode=2)
        self.assertIsNone(rows[0]['r'])
        self.assertAlmostEqual(rows[1]['r'],.1)

    def test_negative_resistance_not_clipped(self):
        s=m.abcd_to_s((1,-.01,0,1),50)
        row=m.extract({'z0':50,'rows':[(1,s)]},mode=2)[0]
        self.assertLess(row['r'],0)
        self.assertIn('Nonpassive terminal data',row['flags'])

    def test_reject_unsupported_data(self):
        valid=file_from_s([(1,[.1,.2,.2,.1])],v2=True)
        for text in (valid.replace('[Reference] 50 50','[Reference] 50 75'),
                     valid.replace('[Matrix Format] Full','[Matrix Format] Lower'),
                     valid.replace('# Hz S RI R 50','# Hz Z RI R 50'),
                     valid.replace('[Number of Ports] 2','[Number of Ports] 4'),
                     valid.replace('[Network Data]','[Mixed-Mode Order] D1,2'),
                     '# Hz S RI R 50\n1 0 0 0 0'):
            with self.assertRaises(ValueError):m.parse_touchstone(text)

    def test_inline_comments_wrapping_and_mhz(self):
        text='# MHz S RI R 50\n1 .1 0 .2 0 ! comment\n .3 0 .4 0\n'
        d=m.parse_touchstone(text)
        self.assertEqual(d['rows'][0],(1e6,[.1+0j,.3+0j,.2+0j,.4+0j]))


if __name__=='__main__':
    unittest.main()

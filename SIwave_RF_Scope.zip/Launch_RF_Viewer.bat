@echo off
cd /d "%~dp0"
py -3 siwave_rf_viewer.py %*
if errorlevel 1 (
  echo.
  echo If the Python launcher is unavailable, run: python siwave_rf_viewer.py
  pause
)
